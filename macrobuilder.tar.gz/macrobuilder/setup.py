from setuptools import setup

setup(name='macrobuilder',
      version='1.0',
      description='MacroBuilder tool.',
      url='',
      author='E.M. del Pico, S. Ozkan, A. Fernandez',
      author_email='',
      license='GPL',
      packages=['macrobuilder'],
      zip_safe=False)


